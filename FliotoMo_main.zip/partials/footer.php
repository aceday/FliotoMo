        <footer class="mt-10 pt-6 border-t border-slate-200 text-sm text-slate-500">
            <p>FliotoMo Systems • TailwindCSS • <?= date('Y'); ?></p>
        </footer>
    </div>
</body>
</html>
